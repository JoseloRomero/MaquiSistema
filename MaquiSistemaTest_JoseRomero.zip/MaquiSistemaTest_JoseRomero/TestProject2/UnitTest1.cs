using MaquiSistema.Controllers;
using MaquiSistema.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace TestProject2
{
    public class ProductTesting : ControllerBase
    {
        private readonly ProductsController _controller;
        private readonly ProductDbContext  _context;
        private readonly DbContextOptions _options;

        public ProductTesting()
        { 
            //_options = new DbContextOptions();
            _context = new ProductDbContext(_options);
            _controller = new ProductsController(_context);
            
        }

        [Fact]
        public void Get_Ok()
        {
            var result = _controller.GetProducts();

            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public void GetProduct_Ok()
        {
            int id = 1;

            var result = _controller.GetProduct(id);

            Assert.IsType<OkObjectResult>(result);
        }

        public void GetProductExists_Ok()
        {
            int id = 1;

            var result = _controller.GetProduct(id);

            var prod = Assert.IsType<Product>(result);

            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(prod.ProductId, id);   
        }

    }
}