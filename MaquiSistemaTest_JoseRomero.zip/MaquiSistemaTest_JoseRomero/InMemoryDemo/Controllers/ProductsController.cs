﻿using MaquiSistema.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace MaquiSistema.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ProductDbContext _context;

        public ProductsController(ProductDbContext context)
        {

            _context = context;
        }

        [HttpGet]

        public List<Product> GetProducts()
        {
            return _context.Products.ToList();
        }

        [HttpGet("{id}")]

        public Product GetProduct(int id)
        {
            return _context.Products.SingleOrDefault(e => e.ProductId == id);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var prod = _context.Products.SingleOrDefault(e => e.ProductId == id);
            if (prod == null)
            {
                return NotFound("Product with the Id:" + id + "does not exist");
            }
            _context.Products.Remove(prod);
            _context.SaveChanges();
            return Ok("Product with the Id:" + id + " deleted succesfully");
        }

        [HttpPost]
        public IActionResult AddProduct(Product product)
        {
            if (product != null) {

                product.FinalPrice = product.Price * ((100 - product.Discount) / 100);

            }

            _context.Products.Add(product);
            _context.SaveChanges();

            return Created("api/products/" + product.ProductId, product);

        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Product product)
        {
            var emp = _context.Products.SingleOrDefault(e => e.ProductId == id);
            if (emp == null)
            {
                return NotFound("Product with the ProductId:" + id + "does not exist");
            }

            if (product.Name != null)
            {
                emp.Name = product.Name;
            }

            if (product.StatusName != null)
            {
                emp.StatusName = product.StatusName;
            }

            if (product.Stock != 0)
            {
                emp.Stock = product.Stock;
            }

            if (product.Description != null)
            {
                emp.Description = product.Description;
            }

            if (product.Price != 0)
            {
                emp.Price = product.Price;
            }

            if (product.Discount != 0)
            {
                emp.Discount = product.Discount;
            }

            emp.FinalPrice =  emp.Price * ((100 - emp.Discount) / 100);

            _context.Update(emp);
            _context.SaveChanges();
            return Ok("Product with the Id:" + id + "Succesfully Updated");


      

    }

}
    }
