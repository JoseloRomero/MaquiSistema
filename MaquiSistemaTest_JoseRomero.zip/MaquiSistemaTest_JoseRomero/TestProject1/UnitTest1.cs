using System;
using Xunit;
using MaquiSistema.

namespace TestProject1
{
    public class ProductTesting
    {
        private readonly ProductsController _controller;
        [Fact]
        public void Test1()
        {

        }
    }
}
